//
//  LogInViewController.swift
//  ShareLoveApp
//
//  Created by Yueya Ou on 2/24/20.
//

import UIKit
import Firebase
import FirebaseAuth

class LogInViewController: UIViewController {

    @IBOutlet weak var email: UITextField!
    @IBOutlet weak var password: UITextField!
    
    
    override func viewDidLoad() {
        super.viewDidLoad()

        // Do any additional setup after loading the view.
    }
    

    /*
    // MARK: - Navigation

    // In a storyboard-based application, you will often want to do a little preparation before navigation
    override func prepare(for segue: UIStoryboardSegue, sender: Any?) {
        // Get the new view controller using segue.destination.
        // Pass the selected object to the new view controller.
    }
    */

    @IBAction func SignIn(_ sender: UIButton) {
        
        if (self.email.text!).count > 0 && (self.password.text!).count > 0
        {
            Auth.auth().signIn(withEmail: self.email.text!, password: self.password.text!) { authResult, error in
            
            guard (authResult?.user) != nil else {
            let errorFound = error! as NSError
            let alert = UIAlertController(title: "Error", message: errorFound.localizedDescription, preferredStyle: .alert)
            alert.addAction(UIAlertAction(title: "OK", style: .cancel, handler: nil))
            self.present(alert, animated: true)
            /*
            switch errorFound.code {
                
            case AuthErrorCode.emailAlreadyInUse.rawValue:
                let alert = UIAlertController(title: "Error", message: "The email address is already in use by another account.", preferredStyle: .alert)
                alert.addAction(UIAlertAction(title: "OK", style: .cancel, handler: nil))
                self.present(alert, animated: true)
            
            case AuthErrorCode.invalidEmail.rawValue:
                let alert = UIAlertController(title: "Error", message: "The email address is malformed.", preferredStyle: .alert)
                alert.addAction(UIAlertAction(title: "OK", style: .cancel, handler: nil))
                self.present(alert, animated: true)
                
            case AuthErrorCode.wrongPassword.rawValue:
                let alert = UIAlertController(title: "Error", message: "The user attempted sign in with a wrong password", preferredStyle: .alert)
                alert.addAction(UIAlertAction(title: "OK", style: .cancel, handler: nil))
                self.present(alert, animated: true)
                
            default:
                print (error!.localizedDescription)
            }
            */
                return
            }
                let alert = UIAlertController(title: "Sign In Successfully", message: nil, preferredStyle: .alert)
                alert.addAction(UIAlertAction(title: "OK", style: .cancel, handler: nil))
                self.present(alert, animated: true)
            }
        }
        else
        {
            let alert = UIAlertController(title: "Error", message: "Username and password cannot be empty.", preferredStyle: .alert)
            alert.addAction(UIAlertAction(title: "OK", style: .cancel, handler: nil))
            self.present(alert, animated: true)
            return
        }
    }
    
}

//
//  ProfileViewController.swift
//  ShareLoveApp
//
//  Created by Yueya Ou on 3/9/20.
//

import UIKit
import Firebase
import FirebaseAuth

/*
extension UIImageView {
   func getData(from url: URL, completion: @escaping (Data?, URLResponse?, Error?) -> ()) {
      URLSession.shared.dataTask(with: url, completionHandler: completion).resume()
   }
   func setImage(from url: URL) {
      getData(from: url) {
         data, response, error in
         guard let data = data, error == nil else {
            return
         }
         DispatchQueue.main.async() {
            self.image = UIImage(data: data)
         }
      }
   }
}
*/

class ProfileViewController: UIViewController {

    @IBOutlet weak var photo: UIImageView!
    @IBOutlet weak var email_address: UILabel!
    @IBOutlet weak var name: UILabel!
    @IBOutlet weak var money_recieved: UILabel!
    @IBOutlet weak var money_sent: UILabel!
    
    override func viewDidLoad() {
        super.viewDidLoad()

        // Do any additional setup after loading the view.
        showProfile()
    }
    

    /*
    // MARK: - Navigation

    // In a storyboard-based application, you will often want to do a little preparation before navigation
    override func prepare(for segue: UIStoryboardSegue, sender: Any?) {
        // Get the new view controller using segue.destination.
        // Pass the selected object to the new view controller.
    }
    */
    var first_name = "", last_name = "", photo_url = ""
    
    func showProfile()
    {
        let destinationReference = Database.database().reference().child("UserList").child((Auth.auth().currentUser?.uid)!)
        
        /*
         var email: String?
         var firstName: String?
         var lastName: String?
         var photo: String?
         var moneyRecieved: Double?
         var moneySent: Double?
         */
        destinationReference.observe(.value, with: { snapshot in
        print(snapshot.children)
            let profile = snapshot.value as? NSDictionary
            let email = profile?["email"] as? String ?? ""
            let firstName = profile?["firstName"] as? String ?? ""
            let lastName = profile?["lastName"] as? String ?? ""
            let moneyRecieved = profile?["moneyRecieved"] as? Double ?? 0.00
            let moneySent = profile?["moneySent"] as? Double ?? 0.00
            let photo = profile?["photo"] as? String ?? ""
            
            
            let photoURL = URL(string: photo)
            let data = try? Data(contentsOf: photoURL!)

            if let imageData = data {
                self.photo.image = UIImage(data: imageData)
            }
            print(photo)
            //self.photo.setImage(from: photoURL!)
            self.email_address.text = email
            self.name.text = firstName + " " + lastName
            self.money_recieved.text = String(moneyRecieved)
            self.money_sent.text = String(moneySent)

            self.first_name = firstName
            self.last_name = lastName
            self.photo_url = photo
            
        }){ (error) in
            print(error.localizedDescription)
        }
    }
    
    override func prepare(for segue: UIStoryboardSegue, sender: Any?) {
        if segue.identifier == "ToEditProfileView"{
            if let toEditProfileViewController: EditProfileViewController = segue.destination as? EditProfileViewController {
                
                toEditProfileViewController.first_name = first_name
                toEditProfileViewController.last_name = last_name
                toEditProfileViewController.photo_url = photo_url
            }
        }
    }
    
    @IBAction func returnFromEditProfileView(segue: UIStoryboardSegue)
    {
        if let viewController = segue.source as? EditProfileViewController{
            
            print(viewController.first_name)
            print(viewController.last_name)
            self.name.text = viewController.first_name + " " + viewController.last_name
            
            let photoURL = URL(string: viewController.photo_url)
            let data = try? Data(contentsOf: photoURL!)

            if let imageData = data {
                self.photo.image = UIImage(data: imageData)
            }
        }
    }
}

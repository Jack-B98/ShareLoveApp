//
//  EditProfileViewController.swift
//  ShareLoveApp
//
//  Created by GreenyAu on 3/10/20.
//

import UIKit
import Photos
import Firebase
import FirebaseAuth

class EditProfileViewController: UIViewController, UITextViewDelegate, UIImagePickerControllerDelegate, UINavigationControllerDelegate {

    var first_name = "", last_name = "", photo_url = ""
    
    @IBOutlet weak var photo: UIImageView!
    @IBOutlet weak var firstName: UITextField!
    @IBOutlet weak var lastName: UITextField!
    
    override func viewDidLoad() {
        super.viewDidLoad()

        // Do any additional setup after loading the view.
        self.firstName.text = first_name
        self.lastName.text = last_name
        
        let photoURL = URL(string: photo_url)
        let data = try? Data(contentsOf: photoURL!)

        if let imageData = data {
            self.photo.image = UIImage(data: imageData)
        }
    }
    
    var pickPhoto: Bool = false
    @IBAction func editPhoto(_ sender: UIButton) {
        if UIImagePickerController.isSourceTypeAvailable(UIImagePickerController.SourceType.photoLibrary) {
            
        let imagePickerController = UIImagePickerController()
        imagePickerController.delegate = self
        imagePickerController.sourceType = .photoLibrary
        self.present(imagePickerController, animated: true, completion: nil)
        }
    }
    
    internal func imagePickerController(_ picker: UIImagePickerController, didFinishPickingMediaWithInfo info: [UIImagePickerController.InfoKey : Any]){
            picker.dismiss(animated: true){
                if let pickedImage = info[.originalImage] as? UIImage {
                    self.photo.image = pickedImage
                    self.pickPhoto = true
                }
            }
        }
        
    func imagePickerControllerDidCancel(_ picker: UIImagePickerController) {
        dismiss(animated: true, completion: nil)
    }

    /*
    // MARK: - Navigation

    // In a storyboard-based application, you will often want to do a little preparation before navigation
    override func prepare(for segue: UIStoryboardSegue, sender: Any?) {
        // Get the new view controller using segue.destination.
        // Pass the selected object to the new view controller.
    }
    */
    @IBAction func updateProfile(_ sender: UIButton) {
        let rootReference = Database.database().reference().child("UserList").child((Auth.auth().currentUser?.uid)!)
        if let new_firstName = self.firstName.text, new_firstName != first_name
        {
            first_name = new_firstName
            print(first_name)
            rootReference.updateChildValues(["firstName":first_name])
        }
        if let new_lastName = self.lastName.text, new_lastName != last_name
        {
            last_name = new_lastName
            print(last_name)
            rootReference.updateChildValues(["lastName":last_name])
        }
        if let new_photo = self.photo.image, pickPhoto == true
        {
            updateProfileImage(new_photo) { url in
                if let new_url = url
                {
                    self.photo_url = new_url.absoluteString
                    rootReference.updateChildValues(["photo":self.photo_url])
                    print("Image URL: \(new_url.absoluteString)")
                }
            }
        }
        
        self.performSegue(withIdentifier: "ReturnToProfileView", sender: self)
    }
    
    func updateProfileImage(_ image:UIImage, completion: @escaping ((_ url:URL?)->())) {
        guard let uid = Auth.auth().currentUser?.uid else { return }
        let storageRef = Storage.storage().reference().child(uid)
        guard let imageData = image.jpegData(compressionQuality: 0.0)
            else { return }
        
        
        let metaData = StorageMetadata()
        metaData.contentType = "image/jpg"
        
        storageRef.putData(imageData, metadata: metaData) { metaData, error in
            
            guard metaData != nil else{
                let errorFound = error! as NSError
                let alert = UIAlertController(title: "Error", message: errorFound.localizedDescription, preferredStyle: .alert)
                alert.addAction(UIAlertAction(title: "OK", style: .cancel, handler: nil))
                self.present(alert, animated: true)
                return
            }
            
            storageRef.downloadURL { url, error in
                if let error = error
                {
                    let alert = UIAlertController(title: "Error", message: error.localizedDescription, preferredStyle: .alert)
                    alert.addAction(UIAlertAction(title: "OK", style: .cancel, handler: nil))
                    self.present(alert, animated: true)
                    return
                }
                else
                {
                    let changeRequest = Auth.auth().currentUser?.createProfileChangeRequest()
                    changeRequest?.photoURL = url
                    
                    changeRequest?.commitChanges { error in
                        if error != nil
                        {
                            print("Error: \(error!.localizedDescription)")
                        }
                    }
                    
                    print("Image URL: \((url?.absoluteString)!)")
                    completion(url)
                }
            }
        }
    }
}

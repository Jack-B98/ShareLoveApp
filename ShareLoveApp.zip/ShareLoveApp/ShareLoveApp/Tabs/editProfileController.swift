//
//  editProfileController.swift
//  Capstone Mock
//
//  Created by boob on 3/4/20.
//  Copyright © 2020 Jack Bryant. All rights reserved.
//

import UIKit

class editProfileController: NSObject {

}
